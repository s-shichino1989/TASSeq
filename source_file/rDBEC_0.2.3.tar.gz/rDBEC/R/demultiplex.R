utils::globalVariables(names = c("i", "difference"),
                       package = 'rDBEC',
                       add = TRUE)

#' Demultiplex_DNAtags
#'
#' Demultiplex and annotate each cells by DNAtag count data based on Z scaling and pam clustering method.
#'
#' @param x A matrix or data.frame of DNAtag count data. first column represents cell ID, colnames represents Tag IDs.
#' @param object A Seurat v2 object created from genes and cells count data
#' @param nTags A number of DNA tags. must be an integer.
#' @param nCells_in_cartridge A number of cells loaded into Rhapsody cartridge. default=20000.
#' @param sample.name A name of sample
#' @param dir.name An output directory name for generate count threshold plots-containing folder
#' @param scale.max An upper limit of centered log2FC value for heatmap visualization. default=3
#' @param scale.min An lower limit of centered log2FC value for heatmap visualization. default=-3
#' @param prefix A character that add to the hashtag names (e.g. -ADT) default=NULL
#' @param scale.factor A global scale facotr for between-hashtag normalization. default=NULL (minimum read number of valid hashtags).
#'
#' @importFrom pheatmap pheatmap
#' @importFrom data.table fwrite
#' @importFrom cluster pam
#' @importFrom grDevices colorRampPalette
#' @importFrom Seurat AddMetaData
#' @importFrom ggplot2 ggsave
#' @importFrom ggplotify as.ggplot
#' @importFrom magrittr %>%
#' @importFrom dplyr top_n
#' @import graphics
#' @importFrom stats density hclust na.omit dpois dist
#' @importFrom Matrix t rowSums
#'
#' @rdname Demultiplex_DNAtags
#' @return A list of Seurat object and demultiplex results ggplot object. Add TadID and Tagcount(first and second highest count) informations into meta.data slot. Also export plots and annotated tables.
#' @export

Demultiplex_DNAtags = function(x,
                               object,
                               nTags=3,
                               nCells_in_cartridge=20000,
                               sample.name="Sample1",
                               dir.name="./",
                               scale.max=3,
                               scale.min=-3,
                               prefix=NULL,
                               scale.factor = NULL

) {
  if (nTags <= 1){stop("must specify more than one Tags.")}
  if (object@version == "2.3.4"){
    data0=x[x$CellBC %in% rownames(object@meta.data), ]
  } else if (object@version >= "3.0"){
    data0=x[x$CellBC %in% as.character(colnames(object)), ]
  }
  rownames(data0)=data0[,1]

  #pick up valid hashtag columns
  data0=data0[,2:ncol(data0)]
  data0=data0[,order(colSums(data0), decreasing = T)]
  data0=data0[,c(1:nTags)]
  data0=data0[,order(colnames(data0), decreasing = F)]

  #log-centered tag count data
  message("log2(x+1)-normalize hashtag count data by global scaling factor")
  #size factor is set as minimum summantion of each hashtag count
  #message("centered by log2 mean count")
  if (is.null(scale.factor)){
    data0  = sweep(data0, 2, STATS=min(colSums(data0)) / colSums(data0), FUN="*")
  } else {
    data0  = sweep(data0, 2, STATS=scale.factor / colSums(data0), FUN="*")
  }
  data1 = data0+1
  data1 = log2(data1)
  data1  = sweep(data1, 1, STATS=apply(data1,1,mean), FUN="-")
  #data1=t(data1)
  #data1=scale(data1, center = TRUE)
  #data1=t(data1)
  data1=as.data.frame(data1)
  data1=na.omit(data1)
  data1$first_most_probable = unlist(apply(data1[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data1$second_most_probable = unlist(apply(data1[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))
  data1$difference = data1$first_most_probable - data1$second_most_probable

  #cut off probable doublets (because SN ratio is not visible)
  message("Detectable doublets will be assessed by Poisson's distribution")
  poisson_notEmpty = 1-dpois(0, lambda=nCells_in_cartridge/200000)
  poisson_singlet = dpois(1, lambda=nCells_in_cartridge/200000)
  pct.doublet = 1-poisson_singlet/poisson_notEmpty
  pct.doublet.detectable = pct.doublet*(choose(nTags+2-1, 2)-nTags)/choose(nTags+2-1, 2)
  pct_of_retain_cells = 1-pct.doublet.detectable

  message(paste("pct of retain cells is ", as.character(round(pct_of_retain_cells, digits=4)*100), "%", sep=''))
  #Must be mentioned that hashtags could only removes doublets derived from Rhapsody cell load step
  #message("Must be mentioned that hashtags could not remove remained doublet cells in the single-cell preparation (enzymatic digestion) step")
  #message("that could assess by FACS analysis. That is why, you must be removed these doublets manually by the expression pattern of marker genes")
  #data2 = data1[order(data1$difference, decreasing = T),]
  #data2 = data1[c(1:round(nrow(data1)*pct_of_retain_cells, digits=0)), ]
  data2 = cbind(rownames(data1), data1)

  if (round(nrow(data1)*pct_of_retain_cells, digits=0) != nrow(data1)){
  #extract doublet data
  doublets = as.data.frame(data2) %>% top_n(-round(nrow(data2)*pct.doublet.detectable, digits=0), difference)
  doublets = as.data.frame(doublets)
  rownames(doublets)=doublets[,1]
  doublets = doublets[,2:ncol(doublets)]
  doublets = doublets[,c(1:nTags)]
  tmp = Matrix::rowSums(doublets) == 0
  tmp1 = rep("doublet", nrow(doublets))
  tmp1[tmp]="not_detected"
  doublets = cbind(doublets, tmp1)
  colnames(doublets) = c(colnames(doublets)[1:nTags], "TagIDs")

  #extract no doublet data
  data2 = data1[setdiff(rownames(data1), rownames(doublets)), ]

  } else {
    message("no doublest could not detect in this experimental condition.")
  }

  #set limit of hashtag Fold-change
  if(nTags==2){
  clusters=data2[,1]
  clusters[clusters>0]=1
  clusters[clusters<0]=2
  names(clusters)=rownames(data2)
  } else{
  clusters = apply(data2[,c(1:nTags)], 1, function(x)(which.max(x)))
  names(clusters)=rownames(data2[,c(1:nTags)])
  #pam_clustering=cluster::pam(temp, k=nTags) #de-multiplex by pam clustering
  #export clustering results
  #clusters = pam_clustering$clustering
  }

  #reorder data of each cluster by hclust
  res1=NULL
  for (i in c(1:nTags)){
    tmp = data2[names(clusters[clusters==i]), c(1:nTags)]
    #tmp=tmp[!apply(tmp,1,sd)==0,]
    tmp=Matrix::t(scale(Matrix::t(tmp),center=TRUE))
    tmp[is.na(tmp)] = 0
    tmp[is.nan(tmp)] = 0
    if(nrow(tmp)>2){
    tmp2 =hclust(dist(tmp, method = "euclidean"), method="ward.D")
    tmp = tmp[tmp2$order,]
    }
    tmp1 = colMeans(tmp)
    names(tmp1)=colnames(tmp)
    tmp = as.data.frame(tmp)
    tmp1=sort(tmp1, decreasing = T)
    tmp3=rep(names(tmp1[1]), nrow(tmp))
    tmp[tmp>scale.max] = scale.max
    tmp[tmp<scale.min] = scale.min
    tmp=cbind(tmp, tmp3)
    colnames(tmp)=c(colnames(tmp)[1:nTags], "TagIDs")
    tmp$TagIDs = as.character(tmp$TagIDs)
    res1 = rbind(res1, tmp)
  }

  if (round(nrow(data1)*pct_of_retain_cells, digits=0) != nrow(data1)){
    temp = doublets[,c(1:nTags)]
    temp=Matrix::t(scale(Matrix::t(temp),center=TRUE))
    temp[is.na(temp)] = 0
    temp[is.nan(temp)] = 0
    if(nrow(doublets)>2){
    tmp2 =hclust(dist(temp, method = "euclidean"), method="ward.D")
    }
    temp[temp>scale.max] = scale.max
    temp[temp<scale.min] = scale.min
    temp = as.data.frame(temp)
    if(nrow(doublets)>2){
    doublets = cbind(temp[tmp2$order,], doublets[tmp2$order,"TagIDs", drop=F])
    } else {
    doublets = cbind(temp, doublets[,"TagIDs", drop=F])
    }
    colnames(doublets)=c(colnames(temp), "TagIDs")
    doublets$TagIDs = as.character(doublets$TagIDs)
    doublets = as.data.frame(doublets)
  }

  file.name = sprintf("%s_demultiplex.txt", sample.name)
  file.name = paste(dir.name, file.name, sep='')

  if (round(nrow(data1)*pct_of_retain_cells, digits=0) != nrow(data1)){
    res1=rbind(res1, doublets)
  }
  fwrite(res1, file.name, sep="\t", quote=F, row.names=T, col.names=T)


  cluster_annot = res1[,"TagIDs",drop=F]
  cluster_annot[,1] = as.character(cluster_annot[,1])
  colnames(cluster_annot) = "TagIDs"

  message("draw demultiplex heatmap...")
  cluster_palette = c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c',
                      '#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',
                      '#49beaa', '#611c35', '#2708a0')
  cluster_colors = cluster_palette[1:length(unique(cluster_annot[,1]))]
  names(cluster_colors) = sort(unique(cluster_annot[,1]))

  annotation_row = cluster_annot
  rownames(annotation_row) = rownames(res1)
  annotation_colors = list(
    TagIDs=cluster_colors
  )

  res1=res1[order(res1$TagIDs, decreasing=F),]

  bks = seq(scale.min-0.1, scale.max+0.1, by = 0.1)
  cols = grDevices::colorRampPalette(c("blue","cyan","white","magenta", "red"))
  brcols=cols(length(bks))
  p = pheatmap(
    res1[,c(1:nTags)],
    scale="none",
    cluster_rows=FALSE,
    cluster_cols=FALSE,
    show_colnames=FALSE,
    show_rownames=FALSE,
    annotation_row=annotation_row,
    annotation_colors = annotation_colors,
    annotation_names_row=FALSE,
    color=brcols,
    breaks = bks,
    main="log2 centered count"
  )
  p = as.ggplot(p[[4]])

  if (is.null(prefix)){
    file.name=sample.name
  } else {
    file.name = paste(sample.name, "-", prefix, sep = "")
  }
  file.name = sprintf("%s_demultiplex.png", file.name)
  file.name = paste(dir.name, file.name, sep='')
  ggsave(file.name, p, device="png", units="in", dpi = 300, width = 5, height = 6, limitsize=FALSE)
  dev.off()

  message("add hashtag/sampletag/Abtag information to Seurat metadata...")

  if (object@version == "2.3.4"){
    raw.data = object@raw.data
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  } else if (object@version >= "3.0"){
    raw.data = GetAssayData(object, slot = "counts", assay="RNA")
    if (dim(raw.data) == 0){stop(message("could not retrive raw count matrix from Seurat object. STOP"))}
    not_annotated_cell = setdiff(colnames(raw.data), rownames(data1))
  }

  annot = as.character(res1[rownames(res1) %in% colnames(raw.data),"TagIDs"])
  names(annot)=rownames(res1[rownames(res1) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = as.character(rep("not_detected",length(not_annotated_cell)))
    names(annot_NA)=setdiff(colnames(raw.data), rownames(data1))
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
    slot.name="TagIDs"
  } else {
    slot.name = paste("TagIDs", "-", prefix, sep = "")
  }
  object = AddMetaData(object = object, metadata = annot, col.name = slot.name)


  # add each normalized hashtag reads into Seurat metadata
  for (i in c(1:nTags)){

  hashtag_name = colnames(data0)[i]
  hashtag_name = paste(hashtag_name, ".log2", sep = "")
  annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),i])
  annot = log2(annot+1)
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])
    if (length(not_annotated_cell) > 0){
     annot_NA = rep(0,length(not_annotated_cell))
     names(annot_NA)=not_annotated_cell
     annot = c(annot, annot_NA)
    }
  object = AddMetaData(object = object, metadata = annot, col.name = hashtag_name)

  }

  # add first and second probable hashtag reads into Seurat metadata
  data0$first_most_probable = unlist(apply(data0[,c(1:nTags)], 1,
                                           FUN = function(x) sort(x, decreasing = TRUE)[1]))
  data0$second_most_probable = unlist(apply(data0[,c(1:nTags)], 1,
                                            FUN = function(x) sort(x, decreasing = TRUE)[2]))

  annot = as.numeric(data0[rownames(data0) %in% colnames(raw.data),"first_most_probable"])
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = rep(0,length(not_annotated_cell))
    names(annot_NA)=not_annotated_cell
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
  slot.name="first_most_probable_TagReads"
  } else {
  slot.name = paste("first_most_probable_TagReads", "-", prefix, sep = "")
  }

  object = AddMetaData(object = object, metadata = annot, col.name = slot.name)

  annot = as.character(data0[rownames(data0) %in% colnames(raw.data),"second_most_probable"])
  names(annot)=rownames(data0[rownames(data0) %in% colnames(raw.data),])

  if (length(not_annotated_cell) > 0){
    annot_NA = rep(0,length(not_annotated_cell))
    names(annot_NA)=not_annotated_cell
    annot = c(annot, annot_NA)
  }

  if (is.null(prefix)){
    slot.name="second_most_probable_TagReads"
  } else {
    slot.name = paste("second_most_probable_TagReads", "-", prefix, sep = "")
  }

  object = AddMetaData(object = object, metadata = annot, col.name = slot.name)

  res = list()
  res[[1]]=object
  res[[2]]=p
  return(res)
}
