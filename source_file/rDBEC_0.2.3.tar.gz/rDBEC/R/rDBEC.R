#' rDBEC
#'
#' Functions to detect backgorund count thresholds for each gene based on
#' count data distibution by R environment
#'
#' @name rDBEC
#' @docType package
#' @importFrom utils globalVariables
NULL
